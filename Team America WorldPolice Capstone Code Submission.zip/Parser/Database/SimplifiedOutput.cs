﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Database
{
    public class SimplifiedOutput
    {
        public ulong value;
        public string publicAddress;
        public uint index;
        public string transactionHash;
        public uint timestamp;
    }
}
