﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Blockchain
{
    public class Output
    {
        public ulong value;
        public ulong VL_outputScriptLength;
        public string publicKeyAddress;
    }
}
