﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Json;

namespace GraphDataStructure
{
    class Program
    {
        static void Main(string[] args)
        {
            int degrees = 2;
            Graph network = Graph.populate("16MEiyzg9qaB1RWBhmcYd8bicVcEiTQJrE", degrees,150);
            network.weigh();
            network.trim(100);
            network.writeJSONToFile(@"C:\Users\wilso_000\Desktop\miserables.html",network.buildJsonString());
        }
    }
}
